import random

print(random.randit(1, 10))
